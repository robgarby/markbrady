import React, { useEffect, useMemo, useState } from "react";
import * as pdfjsLib from "pdfjs-dist";
import { useGlobalContext } from "../../Context/global.context";

pdfjsLib.GlobalWorkerOptions.workerSrc =
  `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

const ENDPOINT = "https://gdmt.ca/PHP/special.php";

const normalize = (s) =>
  String(s || "")
    .toLowerCase()
    .replace(/\u00a0/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();

const readCondName = (c) => String(c?.conditionName ?? c?.name ?? "").trim();
const readCondCode = (c) => String(c?.conditionCode ?? c?.code ?? "").trim();
const readCondId = (c) => String(c?.ID ?? c?.id ?? "").trim();

const toAsciiDigits = (s) =>
  String(s || "").replace(/[０-９]/g, (d) => String.fromCharCode(d.charCodeAt(0) - 0xFF10 + 0x30));

const extractOntarioHCN = (t) => {
  const norm = toAsciiDigits(String(t || ""))
    .replace(/\u00A0/g, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/[\r\n]+/g, " ")
    .trim();

  if (!norm) return "";

  const pickTenDigits = (snippet) => {
    const m = snippet.match(/([A-Za-z]?\s*[\d\s-]{10,}\s*[A-Za-z]{0,2})/);
    if (!m) return "";
    const digits = m[1].replace(/\D+/g, "");
    if (digits.length < 10) return "";
    const ten = digits.slice(0, 10);
    return `${ten.slice(0, 4)} ${ten.slice(4, 7)} ${ten.slice(7, 10)}`;
  };

  const labelRx = /\b(?:OHIP(?:\s*\/\s*RAMQ)?|HCN|Health\s*Number|Health\s*Card(?:\s*Number)?)\b[:#]?\s*/ig;
  for (let m; (m = labelRx.exec(norm)); ) {
    const start = m.index + m[0].length;
    const maybe = pickTenDigits(norm.slice(start, start + 160));
    if (maybe) return maybe;
  }

  const candidates = [];
  const chunkRx = /([A-Za-z]?\s*[\d\s-]{10,}\s*[A-Za-z]{0,2})/g;
  for (let m; (m = chunkRx.exec(norm)); ) {
    const digits = m[1].replace(/\D+/g, "");
    if (digits.length >= 10) {
      candidates.push({ idx: m.index, ten: `${digits.slice(0, 4)} ${digits.slice(4, 7)} ${digits.slice(7, 10)}` });
    }
  }
  return candidates[0]?.ten || "";
};

const extractName = (t) => {
  let first = "";
  let last = "";
  const lastLabel = t.match(/Last\s*Name\s*[:#]?\s*([A-Za-z' -]+)/i);
  const firstLabel = t.match(/First\s*Name\s*[:#]?\s*([A-Za-z' -]+)/i);
  if (lastLabel) last = (lastLabel[1] || "").trim();
  if (firstLabel) first = (firstLabel[1] || "").trim();
  if (!last || !first) {
    const commaStyle = t.match(/\b([A-Z][A-Za-z' -]+)\s*,\s*([A-Z][A-Za-z' -]+)\b/);
    if (commaStyle) {
      last = last || commaStyle[1];
      first = first || commaStyle[2];
    }
  }
  return {
    first: (first || "").replace(/\s+/g, " ").trim(),
    last: (last || "").replace(/\s+/g, " ").trim(),
  };
};

const readPdfAsText = async (file) => {
  const buf = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
  let text = "";
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const pageText = content.items
      .map((it) => ("str" in it ? it.str : (it && it.item && it.item.str) || ""))
      .join(" ");
    text += (i > 1 ? "\n" : "") + pageText;
  }
  return text.replace(/\u00A0/g, " ").replace(/[ \t]+/g, " ").trim();
};

const extractConditionLines = (t) => {
  const normalized = String(t || "")
    .replace(/[ \t]*([•●◦▪])[ \t]*/g, "\n$1 ")
    .replace(/\n{2,}/g, "\n")
    .trim();

  const bulletRegex = /^[•●◦▪]\s+(.*)$/;
  const results = [];
  const seen = new Set();

  for (const line of normalized.split("\n")) {
    const m = line.match(bulletRegex);
    if (!m?.[1]) continue;
    const cleaned = m[1].replace(/[.,;:]+$/g, "").replace(/\s+/g, " ").trim();
    if (!cleaned) continue;
    const key = normalize(cleaned);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    results.push(cleaned);
  }
  return results;
};

const findBestConditionMatch = (text, catalog) => {
  const source = normalize(text);
  if (!source) return null;

  let best = null;
  for (const cond of catalog) {
    const name = readCondName(cond);
    const code = readCondCode(cond);
    const id = readCondId(cond);
    const nameNorm = normalize(name);
    if (!nameNorm) continue;

    let score = 0;
    if (source === nameNorm) score = 100;
    else if (source.includes(nameNorm) || nameNorm.includes(source)) score = 80;
    else {
      const sourceWords = source.split(" ");
      const nameWords = nameNorm.split(" ");
      const overlap = nameWords.filter((w) => sourceWords.includes(w)).length;
      if (overlap > 0) score = Math.min(70, overlap * 20);
    }

    if (score > 0 && (!best || score > best.score)) {
      best = { id, conditionName: name, conditionCode: code, score };
    }
  }
  return best;
};

export default function ReadHospitalConditions({ onHospitalParsed, onHospitalSaved }) {
  const gc = useGlobalContext() || {};
  const { conditionData, updateConditionData } = gc;

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [hcn, setHcn] = useState("");
  const [confirmHCN, setConfirmHCN] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [hcnInDatabase, setHcnInDatabase] = useState(false);
  const [rows, setRows] = useState([]);

  const conditionOptions = useMemo(
    () => (Array.isArray(conditionData) ? conditionData : []).map((c) => ({
      id: readCondId(c),
      conditionName: readCondName(c),
      conditionCode: readCondCode(c),
    })),
    [conditionData]
  );

  useEffect(() => {
    setRows((prev) =>
      prev.map((row) => {
        if (row.status === "ignored") return row;
        const optionStillExists = conditionOptions.find((opt) => opt.id === row.linkedId);
        if (optionStillExists) {
          return {
            ...row,
            linkedId: optionStillExists.id,
            linkedName: optionStillExists.conditionName,
            linkedCode: optionStillExists.conditionCode,
            status: row.status === "linked" ? "linked" : row.status,
          };
        }
        const best = findBestConditionMatch(row.condition, conditionOptions);
        if (!best) return row;
        return {
          ...row,
          linkedId: best.id,
          linkedName: best.conditionName,
          linkedCode: best.conditionCode,
          status: row.status === "new" ? "new" : "linked",
        };
      })
    );
  }, [conditionOptions]);

  const confirmedHcnMatches = useMemo(() => normalize(confirmHCN) === normalize(hcn) && !!hcn, [confirmHCN, hcn]);
  const allRowsResolved = useMemo(
    () => rows.length > 0 && rows.every((row) => row.status === "ignored" || (row.status === "linked" && row.linkedCode)),
    [rows]
  );

  const canProcess = hcnInDatabase && confirmedHcnMatches && allRowsResolved;

  const resetState = () => {
    setErr("");
    setHcn("");
    setConfirmHCN("");
    setFirstName("");
    setLastName("");
    setHcnInDatabase(false);
    setRows([]);
  };

  const onUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    resetState();
    setLoading(true);

    try {
      const rawText = await readPdfAsText(file);
      const extractedHcn = extractOntarioHCN(rawText);
      const { first, last } = extractName(rawText);
      setHcn(extractedHcn);
      setFirstName(first);
      setLastName(last);

      if (extractedHcn) {
        try {
          const res = await fetch(ENDPOINT, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ script: "getStatus", healthNumber: extractedHcn }),
          });
          const data = await res.json();
          setHcnInDatabase(!!data?.exists);
        } catch {
          setHcnInDatabase(false);
        }
      }

      const extractedConditions = extractConditionLines(rawText);
      const preparedRows = extractedConditions.map((condition, index) => {
        const best = findBestConditionMatch(condition, conditionOptions);
        return {
          rowId: `${Date.now()}-${index}`,
          condition,
          linkedId: best?.id || "",
          linkedName: best?.conditionName || "",
          linkedCode: best?.conditionCode || "",
          status: best?.conditionCode ? "linked" : "pending",
          saving: false,
        };
      });
      setRows(preparedRows);

      if (typeof onHospitalParsed === "function") onHospitalParsed();
    } catch (ex) {
      setErr(ex?.message || "Failed to process PDF");
    } finally {
      setLoading(false);
      e.target.value = "";
    }
  };

  const updateRow = (rowId, patch) => {
    setRows((prev) => prev.map((row) => (row.rowId === rowId ? { ...row, ...patch } : row)));
  };

  const handleSelectExisting = (rowId, optionId) => {
    const option = conditionOptions.find((opt) => String(opt.id) === String(optionId));
    if (!option) {
      updateRow(rowId, { linkedId: "", linkedName: "", linkedCode: "", status: "pending" });
      return;
    }
    updateRow(rowId, {
      linkedId: option.id,
      linkedName: option.conditionName,
      linkedCode: option.conditionCode,
      status: "linked",
    });
  };

  const saveNewCondition = async (row) => {
    if (!row.linkedCode) {
      updateRow(row.rowId, { status: "pending" });
      return;
    }

    updateRow(row.rowId, { saving: true });
    try {
      const resp = await fetch(ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          script: "saveConditionData",
          conditions: {
            conditionName: row.condition,
            code: row.linkedCode,
          },
        }),
      });
      const payload = await resp.json();
      const newConditions = Array.isArray(payload?.conditions) ? payload.conditions : [];
      if (newConditions.length && typeof updateConditionData === "function") {
        updateConditionData(newConditions);
      }
      const savedMatch = newConditions.find((c) => normalize(readCondName(c)) === normalize(row.condition) && readCondCode(c) === row.linkedCode)
        || newConditions.find((c) => normalize(readCondName(c)) === normalize(row.condition));

      updateRow(row.rowId, {
        linkedId: readCondId(savedMatch),
        linkedName: readCondName(savedMatch) || row.condition,
        linkedCode: readCondCode(savedMatch) || row.linkedCode,
        status: "linked",
        saving: false,
      });
    } catch (e) {
      console.error(e);
      updateRow(row.rowId, { saving: false });
      setErr("Could not save the new condition mapping.");
    }
  };

  const processHospital = async () => {
    if (!canProcess) return;
    const conditionCodes = rows
      .filter((row) => row.status === "linked" && row.linkedCode)
      .map((row) => row.linkedCode)
      .filter(Boolean)
      .join(",");

    try {
      const res = await fetch(ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          script: "postMeds",
          healthNumber: hcn,
          conditionCodes,
          medicationIDs: "",
        }),
      });
      const data = await res.json();
      if (data?.success && typeof onHospitalSaved === "function") onHospitalSaved();
      if (!data?.success) setErr("Hospital report could not be processed.");
    } catch (e) {
      console.error(e);
      setErr("Hospital report could not be processed.");
    }
  };

  return (
    <div className={`p-2 alert ${!hcnInDatabase && hcn ? "alert-danger" : "alert-light"}`}>
      <input type="file" accept="application/pdf" className="form-control" onChange={onUpload} />

      {loading ? <div className="mt-2 text-muted">Reading hospital report…</div> : null}
      {err ? <div className="mt-2 text-danger small">{err}</div> : null}

      {(hcn || lastName || firstName) && (
        <div className="mt-3 mb-2">
          <div className="fw-bold">HCN: <span className="text-danger">{hcn || "—"}</span></div>
          <div className="fw-bold">{lastName || firstName ? `${lastName || ""}${lastName && firstName ? ", " : ""}${firstName || ""}` : "Name: —"}</div>
          {!hcnInDatabase && hcn ? <div className="small text-danger mt-1">This health card number is not linked to a patient in the database yet.</div> : null}
        </div>
      )}

      {rows.length > 0 && (
        <>
          <div className="mt-3 mb-2 fw-bold">Please confirm the Health Card Number for this hospital report</div>
          <input
            type="text"
            className={`form-control ${confirmHCN && !confirmedHcnMatches ? "is-invalid" : confirmedHcnMatches ? "is-valid" : ""}`}
            value={confirmHCN}
            onChange={(e) => setConfirmHCN(e.target.value)}
            placeholder="Re-enter Health Card Number"
          />

          <div className="mt-3">
            <div className="d-flex align-items-center justify-content-between mb-2">
              <h6 className="m-0">Conditions from hospital form</h6>
              <button type="button" className="btn btn-sm btn-primary" disabled={!canProcess} onClick={processHospital}>
                Process Hospital Record
              </button>
            </div>

            <div className="table-responsive">
              <table className="table table-sm align-middle">
                <thead>
                  <tr>
                    <th>Condition</th>
                    <th>Found in Table as</th>
                    <th>Condition Code</th>
                    <th className="text-nowrap">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => (
                    <tr key={row.rowId} className={row.status === "ignored" ? "table-secondary" : ""}>
                      <td>{row.condition}</td>
                      <td>
                        <select
                          className="form-select form-select-sm"
                          value={row.linkedId}
                          disabled={row.status === "ignored"}
                          onChange={(e) => handleSelectExisting(row.rowId, e.target.value)}
                        >
                          <option value="">Select condition…</option>
                          {conditionOptions.map((opt) => (
                            <option key={opt.id || `${opt.conditionName}-${opt.conditionCode}`} value={opt.id}>
                              {opt.conditionName}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td>
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          value={row.linkedCode}
                          disabled={row.status === "ignored"}
                          onChange={(e) => updateRow(row.rowId, { linkedCode: e.target.value, status: row.linkedId ? "linked" : "new" })}
                          placeholder="Enter code"
                        />
                      </td>
                      <td className="text-nowrap">
                        <button
                          type="button"
                          className="btn btn-sm btn-outline-success me-2"
                          disabled={row.status === "ignored" || row.saving || !(row.linkedCode && !row.linkedId)}
                          onClick={() => saveNewCondition(row)}
                        >
                          {row.saving ? "Saving..." : "Save"}
                        </button>
                        <button
                          type="button"
                          className="btn btn-sm btn-outline-secondary"
                          onClick={() => updateRow(row.rowId, { status: row.status === "ignored" ? "pending" : "ignored" })}
                        >
                          {row.status === "ignored" ? "Unignore" : "Ignore"}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="small text-muted">
              Every condition must be either ignored or linked to a condition code before the hospital record can be processed.
            </div>
          </div>
        </>
      )}
    </div>
  );
}
